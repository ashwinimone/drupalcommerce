This directory contains translation files for the Commerce Commons module.
